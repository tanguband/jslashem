/*	SCCS Id: @(#)gnyesno.h	3.4	2000/07/16	*/
/* Copyright (C) 1998 by Erik Andersen <andersee@debian.org> */
/* NetHack may be freely redistributed.  See license for details. */

#ifndef GnomeHackYesNoDialog_h
#define GnomeHackYesNoDialog_h

int ghack_yes_no_dialog( const char* szQuestionStr, 
	const char* szChoicesStr, int nDefault);


#endif
