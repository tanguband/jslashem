/*
**
**	$Id: jpatchlevel.h,v 1.13 2008/03/01 13:23:09 so-miya Exp $
**
*/

/* Copyright (c) Issei Numata 1994-2000 */
/* JNetHack may be freely redistributed.  See license for details. */

#define JVERSION_MAJOR	0
#define JVERSION_MINOR	2
#define JPATCHLEVEL	1
#define JEDITLEVEL	0
