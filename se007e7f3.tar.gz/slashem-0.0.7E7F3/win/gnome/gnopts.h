/*	SCCS Id: @(#)gnopts.h	3.4	2000/07/16	*/
/* Copyright (C) 1998 by Erik Andersen <andersee@debian.org> */
/* NetHack may be freely redistributed.  See license for details. */

#ifndef GnomeHackSettings_h
#define GnomeHackSettings_h


void ghack_settings_dialog( void);


#endif /* GnomeHackSettings.h */

