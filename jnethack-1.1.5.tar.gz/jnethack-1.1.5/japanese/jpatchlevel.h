/*
**
**	$Id: jpatchlevel.h,v 1.1.3.1 1999/11/17 06:35:05 issei Exp issei $
**
*/

/* Copyright (c) Issei Numata 1994-2000 */
/* JNetHack may be freely redistributed.  See license for details. */

#define JVERSION_MAJOR	1
#define JVERSION_MINOR	1
#define JPATCHLEVEL	5
#define JEDITLEVEL	0

