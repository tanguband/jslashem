
/* EMS handler routine
   Copyright (c) Kouji Takada 1994 */
/* JNetHack may be freely redistributed.  See license for details. */

int	detect_ems(void);
void	done_ems(void);
void	*emalloc(unsigned int);

