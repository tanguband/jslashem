/*
**
**	$Id: jpatchlevel.h,v 1.4 1996/07/17 06:04:46 issei Exp issei $
**
*/

/* Copyright (c) Issei Numata 1994-1996 */
/* JNetHack may be freely redistributed.  See license for details. */

#define JVERSION_MAJOR 1
#define JVERSION_MINOR 0
#define JPATCHLEVEL    5
#define JEDITLEVEL     3
